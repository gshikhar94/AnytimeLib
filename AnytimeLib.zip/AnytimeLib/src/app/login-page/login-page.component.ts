import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../providers/auth.service';
import { AngularFireDatabase } from "angularfire2/database";
import { Users } from "../Users";
@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  users: Array<Users>;

  constructor(public authService: AuthService, private router: Router, public angularFireDatabase: AngularFireDatabase) { }
  ngOnInit() {
    // this.authService.getCurrentUserObservable().subscribe(user => {
    //   if (user) {
    //     this.router.navigate(['/bookDetails']);
    //   }
    //   else {
    //     this.router.navigate(['/login']);
    //   }
    // })

  }
  loginWithGoogle() {
    this.authService.loginWithGoogle().then((data) => {
      this.router.navigate(['/bookDetails']);

    })
  }

  login(email: string, password: string) {
    this.authService.login(email, password).then(
      (success) => {
        this.router.navigate(['/bookDetails']);
        console.log(success);
      }).catch(error => {
        this.router.navigate(['/login']);
        console.log(error);
      });
  }
  // this.angularFireDatabase.list('/Users', ref => ref.orderByChild('email').equalTo(email)).valueChanges().subscribe(data => console.log(data));




}
