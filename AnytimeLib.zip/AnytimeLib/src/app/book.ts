export class book {
    id: number;
    name: string;
    authorName: string;
    imageUrl: string;
    issued: number;
    totalCopies: number;
    category: string;
    likes: number;
    isIssued: boolean;
    isReturned: boolean;

}