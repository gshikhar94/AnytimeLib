import { Injectable } from '@angular/core';
import { AngularFireAuth } from "angularfire2/auth";
import * as firebase from 'firebase';
import { Users } from "../Users";
import { Observable } from "rxjs/Observable";
import { AngularFireDatabase } from "angularfire2/database";
import { Router } from '@angular/router';

@Injectable()
export class AuthService {
  authState: any = null;
  constructor(public af: AngularFireAuth, public database: AngularFireDatabase, public router: Router) {
    // af.authState.subscribe(auth => this.authState = auth);
  }

  loginWithGoogle() {
    return this.af.auth.signInWithPopup(new firebase.auth.GoogleAuthProvider());
  }

  login(email: string, password: string) {
    return this.af.auth.signInWithEmailAndPassword(
      email,
      password
    )
  }

  logout() {
    this.af.auth.signOut();
    this.router.navigate(['/login']);
  }
  getAuthenticated(): boolean {
    return this.authState !== null;
  }
  getCurrentUser(): any {
    return this.getAuthenticated() ? this.authState : null;
  }
  getCurrentUserId(): any {
    return this.getAuthenticated() ? this.authState.uid : null;
  }
  getPhotoUrl(): any {
    return this.getAuthenticated() ? this.authState.photoURL : null;
  }
  getName(): any {
    return this.getAuthenticated() ? this.authState.displayName : null;
  }
  getEmail(): any {
    return this.getAuthenticated() ? this.authState.email : null;
  }
  getPhone(): any {
    return this.getAuthenticated() ? this.authState.phoneNumber : null;
  }
  getCurrentUserObservable(): any {
    return this.af.authState;
  }
  saveCurrentUser(name: string, phone: string, dob: string, email: string, password: string, id: string) {
    console.log("hi");
    if (phone != undefined && dob != undefined && email != undefined && password != undefined) {
      let user = new Users(phone, dob, name, password, id, email, null);
      this.database.database.ref('/Users').child(id).set(user).
        then(success =>
          this.router.navigate(['/login']).
            catch(error =>
              console.log("Data has not been added to the database" + error))

        )
    }
    else {
      let user = new Users(this.getPhone(), null, this.getName(), null, this.getCurrentUserId(), this.getEmail(), this.getPhotoUrl());
      this.database.database.ref('/Users').child(this.getCurrentUserId()).set(user);
    }
  }
  getCurrentUserDetails(userId: string) {
    //  this.database.list<Users>('/Users/').valueChanges().forEach(users => users.filter(user => {
    //    this.database.object<Users>('/Users/' + userId);
    //   return issuedUserId;
    // }))

    return this.database.list<Users>('/Users', ref => ref.orderByChild('userId').equalTo(userId).limitToFirst(1)).valueChanges()
  }
}
