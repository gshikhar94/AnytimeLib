import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../providers/auth.service';
import * as firebase from 'firebase';
import { querybase } from "querybase";
import { } from "module";
import { AngularFireDatabase } from "angularfire2/database";
import { Users } from "../Users";


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  items: any;
  users: Array<Users>;
  constructor(public af: AuthService, public router: Router, public authDatabase: AngularFireDatabase, public authService: AuthService) {
    this.users = [];
  }

  ngOnInit() {

  }

  signup(name: string, phone: string, dob: string, email: string, password: string) {
    // this.users.Phone = phone;
    let user = new Users(phone, dob, name, password, null, email, null);
    this.users.push(user);
    console.log(this.users.forEach((values) => { console.log(values) }));

    //This code is to push the object into the database
    var ref = this.authDatabase.list('/Users').push(user);

    //This will create a new user with the email and password entered at the time of signup
    this.authService.af.auth.createUserWithEmailAndPassword(email, password);
    if (ref) {
      console.log("Data has been added successfully" + ref.key);
      ref.update({
        id: ref.key
      })
      this.authService.saveCurrentUser(name, phone, dob, email, password, ref.key);
    }

  }
}
