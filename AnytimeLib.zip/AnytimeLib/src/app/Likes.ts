export class Likes{
    bookId:number;
    bookLikes:number;
    userId:any;

}